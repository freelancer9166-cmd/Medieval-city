package com.my.medievalcity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class CharacterActivity extends Activity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_character);
		
		TextView tvName = findViewById(R.id.tvCharName);
		TextView tvPlayerId = findViewById(R.id.tvPlayerId);
		TextView tvLevel = findViewById(R.id.tvLevel);
		TextView tvGold = findViewById(R.id.tvGold);
		TextView tvStrength = findViewById(R.id.tvStrength);
		TextView tvDefense = findViewById(R.id.tvDefense);
		TextView tvStamina = findViewById(R.id.tvStamina);
		
		Player player = MainActivity.getPlayer();
		
		if (player != null) {
			tvName.setText("Name: " + player.getName());
			
			String playerIdText = "🆔 Player ID: " + player.getPlayerId();
			tvPlayerId.setText(playerIdText);
			
			tvLevel.setText("Level: " + player.getLevel());
			tvGold.setText("💰 Gold: " + player.getGold());
			tvStrength.setText("⚔️ Strength: " + player.getStrength());
			tvDefense.setText("🛡️ Defense: " + player.getDefense());
			tvStamina.setText("🏃 Stamina: " + player.getStamina());
			} else {
			Toast.makeText(this, "Player data error!", Toast.LENGTH_SHORT).show();
		}
		
		Button btnBack = findViewById(R.id.btnBack);
		btnBack.setOnClickListener(v -> finish());
	}
}
package com.my.medievalcity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class CraftingActivity extends Activity {
	
	private Player player;
	private TextView tvGold, tvResources;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_crafting);
		
		player = MainActivity.getPlayer();
		tvGold = findViewById(R.id.tvPlayerGoldCraft);
		tvResources = findViewById(R.id.tvResources);
		
		updateDisplays();
		
		// Crafting buttons
		findViewById(R.id.btnCraftSword).setOnClickListener(v -> craftItem("Stone Sword", 7, 20, 12, 0, 20, 20));
		findViewById(R.id.btnCraftAxe).setOnClickListener(v -> craftItem("Stone Axe", 8, 30, 0, 0, 10, 20));
		findViewById(R.id.btnCraftPickaxe).setOnClickListener(v -> craftItem("Stone Pickaxe", 9, 30, 0, 0, 10, 20));
		findViewById(R.id.btnCraftIronSword).setOnClickListener(v -> craftIronSword());
		
		findViewById(R.id.btnBack).setOnClickListener(v -> finish());
	}
	
	private void updateDisplays() {
		tvGold.setText("💰 Gold: " + player.getGold());
		tvResources.setText("🌲 Wood: " + player.getWood() +
		"    ⛰️ Stone: " + player.getStone() +
		"    ⚒️ Iron Ore: " + countIronOre());
	}
	
	private int countIronOre() {
		int count = 0;
		for (Item item : player.getInventory()) {
			if (item.getName().equals("Iron Ore")) count++;
		}
		return count;
	}
	
	private void craftItem(String name, int id, int sellValue, int strBonus, int defBonus, int woodCost, int stoneCost) {
		if (player.getWood() >= woodCost && player.getStone() >= stoneCost) {
			player.setWood(player.getWood() - woodCost);
			player.setStone(player.getStone() - stoneCost);
			player.addItem(new Item(name, id, sellValue, strBonus, defBonus));
			updateDisplays();
			Toast.makeText(this, "✅ Crafted " + name + "!", Toast.LENGTH_LONG).show();
			} else {
			Toast.makeText(this, "Not enough resources!", Toast.LENGTH_SHORT).show();
		}
	}
	
	private void craftIronSword() {
		if (player.getWood() >= 10 && countIronOre() >= 3) {
			player.setWood(player.getWood() - 10);
			
			// Remove 3 Iron Ore
			int removed = 0;
			for (int i = player.getInventory().size() - 1; i >= 0 && removed < 3; i--) {
				if (player.getInventory().get(i).getName().equals("Iron Ore")) {
					player.getInventory().remove(i);
					removed++;
				}
			}
			
			player.addItem(new Item("Iron Sword", 10, 200, 18, 0));
			updateDisplays();
			Toast.makeText(this, "✅ Crafted Iron Sword! (+18 Strength)", Toast.LENGTH_LONG).show();
			} else {
			Toast.makeText(this, "Need 10 Wood + 3 Iron Ore", Toast.LENGTH_SHORT).show();
		}
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		if (player != null) player.save(this);
	}
}
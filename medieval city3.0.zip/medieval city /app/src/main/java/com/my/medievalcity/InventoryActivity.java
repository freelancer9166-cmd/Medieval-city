package com.my.medievalcity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class InventoryActivity extends Activity {
	
	private Player player;
	private LinearLayout layoutItems;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_inventory);
		
		player = MainActivity.getPlayer();
		layoutItems = findViewById(R.id.layoutItems);
		
		updateInventoryDisplay();
		
		Button btnBack = findViewById(R.id.btnBack);
		btnBack.setOnClickListener(v -> finish());
	}
	
	private void updateInventoryDisplay() {
		layoutItems.removeAllViews();
		
		// Resources
		addResourceRow("🌲 Wood", player.getWood());
		addResourceRow("⛰️ Stone", player.getStone());
		
		// Equipped Items
		if (player.getEquippedWeapon() != null || player.getEquippedTool() != null) {
			TextView equippedTitle = new TextView(this);
			equippedTitle.setText("\n⚔️ Equipped:");
			equippedTitle.setTextSize(18);
			layoutItems.addView(equippedTitle);
			
			if (player.getEquippedWeapon() != null) {
				addItemRow(player.getEquippedWeapon(), true);
			}
			if (player.getEquippedTool() != null) {
				addItemRow(player.getEquippedTool(), true);
			}
		}
		
		// Inventory Items
		TextView invTitle = new TextView(this);
		invTitle.setText("\n🎒 Inventory:");
		invTitle.setTextSize(18);
		layoutItems.addView(invTitle);
		
		if (player.getInventory().isEmpty()) {
			TextView empty = new TextView(this);
			empty.setText("No items");
			layoutItems.addView(empty);
			return;
		}
		
		for (Item item : player.getInventory()) {
			addItemRow(item, false);
		}
	}
	
	private void addResourceRow(String name, int amount) {
		TextView tv = new TextView(this);
		tv.setText(name + ": " + amount);
		tv.setTextSize(16);
		tv.setPadding(0, 8, 0, 8);
		layoutItems.addView(tv);
	}
	
	private void addItemRow(Item item, boolean isEquipped) {
		LinearLayout row = new LinearLayout(this);
		row.setOrientation(LinearLayout.HORIZONTAL);
		row.setPadding(0, 8, 0, 8);
		
		TextView tvItem = new TextView(this);
		String effect = "";
		if (item.getStrBonus() > 0) effect += " + " + item.getStrBonus() + " Str";
		if (item.getDefBonus() > 0) effect += " + " + item.getDefBonus() + " Def";
		
		tvItem.setText("• " + item.getName() + effect);
		tvItem.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
		
		Button btnAction = new Button(this);
		if (isEquipped) {
			btnAction.setText("Unequip");
			btnAction.setOnClickListener(v -> {
				if (item.getName().contains("Sword")) player.equipWeapon(null);
				else player.equipTool(null);
				updateInventoryDisplay();
				Toast.makeText(this, "Unequipped " + item.getName(), Toast.LENGTH_SHORT).show();
			});
			} else {
			btnAction.setText(item.getName().contains("Sword") ? "Equip Weapon" : "Equip Tool");
			btnAction.setOnClickListener(v -> {
				if (item.getName().contains("Sword")) {
					player.equipWeapon(item);
					} else if (item.getName().contains("Axe") || item.getName().contains("Pickaxe")) {
					player.equipTool(item);
				}
				updateInventoryDisplay();
				Toast.makeText(this, "Equipped " + item.getName(), Toast.LENGTH_SHORT).show();
			});
		}
		
		row.addView(tvItem);
		row.addView(btnAction);
		layoutItems.addView(row);
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		if (player != null) player.save(this);
	}
}
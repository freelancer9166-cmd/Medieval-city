package com.my.medievalcity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class TradeActivity extends Activity {
	
	private Player player;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_trade);
		
		player = MainActivity.getPlayer();
		
		TextView tvMyId = findViewById(R.id.tvMyPlayerId);
		tvMyId.setText("Your Player ID: " + player.getPlayerId());
		
		TextView tvOffers = findViewById(R.id.tvOffersList);
		tvOffers.setText("No active offers yet.");
		
		Button btnCreateOffer = findViewById(R.id.btnCreateOffer);
		Button btnBack = findViewById(R.id.btnBack);
		
		btnCreateOffer.setOnClickListener(v -> {
			Toast.makeText(this, "Trade Offer Creator coming soon!", Toast.LENGTH_SHORT).show();
		});
		
		btnBack.setOnClickListener(v -> finish());
	}
}
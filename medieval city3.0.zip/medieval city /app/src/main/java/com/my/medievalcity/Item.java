package com.my.medievalcity;

public class Item {
	private String name;
	private int id;
	private int value;        // sell price
	private int strBonus;
	private int defBonus;
	
	public Item(String name, int id, int value, int strBonus, int defBonus) {
		this.name = name;
		this.id = id;
		this.value = value;
		this.strBonus = strBonus;
		this.defBonus = defBonus;
	}
	
	public String getName() { return name; }
	public int getId() { return id; }
	public int getValue() { return value; }
	public int getStrBonus() { return strBonus; }
	public int getDefBonus() { return defBonus; }
	
	@Override
	public String toString() {
		return name + " (ID:" + id + ")";
	}
}
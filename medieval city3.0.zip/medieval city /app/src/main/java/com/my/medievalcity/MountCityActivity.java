package com.my.medievalcity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MountCityActivity extends Activity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_mount_city);
		
		Button btnMarket = findViewById(R.id.btnMarket);
		Button btnCrafting = findViewById(R.id.btnCrafting);
		Button btnTrade = findViewById(R.id.btnTrade);
		Button btnBack = findViewById(R.id.btnBack);
		
		btnMarket.setOnClickListener(v ->
		startActivity(new Intent(this, MarketActivity.class)));
		
		btnCrafting.setOnClickListener(v ->
		startActivity(new Intent(this, CraftingActivity.class)));
		
		btnTrade.setOnClickListener(v ->
		startActivity(new Intent(this, TradeActivity.class)));
		
		btnBack.setOnClickListener(v -> finish());
	}
}
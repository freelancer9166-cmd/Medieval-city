package com.my.medievalcity;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Player {
	private String name;
	private String playerId;
	private int level;
	private int gold;
	private int strength;
	private int defense;
	private int stamina;
	private int xp;
	private int wood;
	private int stone;
	
	private Item equippedWeapon;
	private Item equippedTool;
	
	private List<Item> inventory;
	
	public Player(String name) {
		this.name = name;
		this.playerId = UUID.randomUUID().toString().substring(0, 8).toUpperCase();
		this.level = 1;
		this.gold = 10000;
		this.strength = 10;
		this.defense = 8;
		this.stamina = 15;
		this.xp = 0;
		this.wood = 0;
		this.stone = 0;
		this.inventory = new ArrayList<>();
		// Old Dagger removed as requested
	}
	
	// Getters & Setters
	public String getPlayerId() { return playerId != null ? playerId : "ERROR"; }
	public String getName() { return name; }
	public void setName(String name) { this.name = name; }
	public int getLevel() { return level; }
	public int getGold() { return gold; }
	public void setGold(int gold) { this.gold = gold; }
	public int getStrength() { return strength; }
	public void setStrength(int strength) { this.strength = strength; }
	public int getDefense() { return defense; }
	public void setDefense(int defense) { this.defense = defense; }
	public int getStamina() { return stamina; }
	public void setStamina(int stamina) { this.stamina = stamina; }
	public int getXp() { return xp; }
	
	public int getWood() { return wood; }
	public void setWood(int wood) { this.wood = wood; }
	public int getStone() { return stone; }
	public void setStone(int stone) { this.stone = stone; }
	
	public Item getEquippedWeapon() { return equippedWeapon; }
	public Item getEquippedTool() { return equippedTool; }
	public void equipWeapon(Item item) { this.equippedWeapon = item; }
	public void equipTool(Item item) { this.equippedTool = item; }
	
	public List<Item> getInventory() { return inventory; }
	public void addItem(Item item) { inventory.add(item); }
	public boolean removeItem(Item item) { return inventory.remove(item); }
	
	public void save(Context context) {
		SharedPreferences prefs = context.getSharedPreferences("MedievalCity", Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = prefs.edit();
		
		editor.putString("playerId", playerId);
		editor.putString("name", name);
		editor.putInt("level", level);
		editor.putInt("gold", gold);
		editor.putInt("strength", strength);
		editor.putInt("defense", defense);
		editor.putInt("stamina", stamina);
		editor.putInt("xp", xp);
		editor.putInt("wood", wood);
		editor.putInt("stone", stone);
		
		editor.putInt("equippedWeaponId", equippedWeapon != null ? equippedWeapon.getId() : -1);
		editor.putInt("equippedToolId", equippedTool != null ? equippedTool.getId() : -1);
		
		StringBuilder sb = new StringBuilder();
		for (Item item : inventory) {
			sb.append(item.getId()).append("|")
			.append(item.getName()).append("|")
			.append(item.getValue()).append("|")
			.append(item.getStrBonus()).append("|")
			.append(item.getDefBonus()).append(",");
		}
		editor.putString("inventory", sb.toString());
		editor.apply();
	}
	
	public static Player load(Context context) {
		SharedPreferences prefs = context.getSharedPreferences("MedievalCity", Context.MODE_PRIVATE);
		String name = prefs.getString("name", "KnightErrant");
		
		Player player = new Player(name);
		String savedId = prefs.getString("playerId", null);
		if (savedId != null) player.playerId = savedId;
		
		player.level = prefs.getInt("level", 1);
		player.gold = prefs.getInt("gold", 10000);
		player.strength = prefs.getInt("strength", 10);
		player.defense = prefs.getInt("defense", 8);
		player.stamina = prefs.getInt("stamina", 15);
		player.xp = prefs.getInt("xp", 0);
		player.wood = prefs.getInt("wood", 0);
		player.stone = prefs.getInt("stone", 0);
		
		String invString = prefs.getString("inventory", "");
		if (!invString.isEmpty()) {
			player.inventory = new ArrayList<>();
			String[] items = invString.split(",");
			for (String str : items) {
				if (str.trim().isEmpty()) continue;
				String[] parts = str.split("\\|");
				if (parts.length >= 5) {
					int id = Integer.parseInt(parts[0]);
					String itemName = parts[1];
					int value = Integer.parseInt(parts[2]);
					int strB = Integer.parseInt(parts[3]);
					int defB = Integer.parseInt(parts[4]);
					Item item = new Item(itemName, id, value, strB, defB);
					player.inventory.add(item);
				}
			}
		}
		
		int weaponId = prefs.getInt("equippedWeaponId", -1);
		int toolId = prefs.getInt("equippedToolId", -1);
		for (Item item : player.inventory) {
			if (item.getId() == weaponId) player.equippedWeapon = item;
			if (item.getId() == toolId) player.equippedTool = item;
		}
		
		return player;
	}
}
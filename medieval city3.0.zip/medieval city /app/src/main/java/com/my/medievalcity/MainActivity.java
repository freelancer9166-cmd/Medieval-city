package com.my.medievalcity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	
	private static Player player;
	private TextView tvWelcome;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		if (player == null) {
			player = Player.load(this);
		}
		
		tvWelcome = findViewById(R.id.tvWelcome);
		tvWelcome.setText("Welcome to the realm, " + player.getName() + "!");
		
		Button btnCharacter = findViewById(R.id.btnCharacter);
		Button btnInventory = findViewById(R.id.btnInventory);
		Button btnMap = findViewById(R.id.btnMap);           // Updated
		Button btnCombat = findViewById(R.id.btnCombat);
		Button btnLogin = findViewById(R.id.btnLogin);
		
		btnCharacter.setOnClickListener(v -> startActivity(new Intent(this, CharacterActivity.class)));
		btnInventory.setOnClickListener(v -> startActivity(new Intent(this, InventoryActivity.class)));
		btnMap.setOnClickListener(v -> startActivity(new Intent(this, MapActivity.class)));
		
		btnCombat.setOnClickListener(v -> Toast.makeText(this, "Combat coming soon...", Toast.LENGTH_SHORT).show());
		btnLogin.setOnClickListener(v -> Toast.makeText(this, "Full multiplayer coming soon...", Toast.LENGTH_LONG).show());
	}
	
	public static Player getPlayer() {
		return player;
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		if (player != null) player.save(this);
	}
}
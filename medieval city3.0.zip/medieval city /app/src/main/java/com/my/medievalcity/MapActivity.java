package com.my.medievalcity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MapActivity extends Activity {
	
	private Player player;
	private TextView tvWood, tvStone, tvStatus;
	private Button btnForest, btnQuarry;
	private CountDownTimer activeTimer;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_map);
		
		player = MainActivity.getPlayer();
		
		tvWood = findViewById(R.id.tvWood);
		tvStone = findViewById(R.id.tvStone);
		tvStatus = findViewById(R.id.tvStatus);
		btnForest = findViewById(R.id.btnForest);
		btnQuarry = findViewById(R.id.btnQuarry);
		
		checkOngoingHarvest();
		updateResources();
		
		findViewById(R.id.btnMountCity).setOnClickListener(v ->
		startActivity(new Intent(this, MountCityActivity.class)));
		
		btnForest.setOnClickListener(v -> startHarvesting("wood"));
		btnQuarry.setOnClickListener(v -> startHarvesting("stone"));
		
		findViewById(R.id.btnBack).setOnClickListener(v -> finish());
	}
	
	private void checkOngoingHarvest() {
		SharedPreferences prefs = getSharedPreferences("MedievalCity", MODE_PRIVATE);
		long woodStart = prefs.getLong("harvest_wood_start", 0);
		long stoneStart = prefs.getLong("harvest_stone_start", 0);
		long now = System.currentTimeMillis();
		
		if (woodStart > 0 && now - woodStart < getHarvestDuration("wood")) {
			startTimerFromTime("wood", woodStart);
		}
		if (stoneStart > 0 && now - stoneStart < getHarvestDuration("stone")) {
			startTimerFromTime("stone", stoneStart);
		}
	}
	
	private long getHarvestDuration(String type) {
		boolean hasTool = type.equals("wood") ?
		(player.getEquippedTool() != null && player.getEquippedTool().getName().contains("Axe")) :
		(player.getEquippedTool() != null && player.getEquippedTool().getName().contains("Pickaxe"));
		return hasTool ? 60_000 : 120_000; // 1 or 2 minutes
	}
	
	private void startHarvesting(String type) {
		if (isHarvesting(type)) {
			Toast.makeText(this, "Already harvesting!", Toast.LENGTH_SHORT).show();
			return;
		}
		
		long duration = getHarvestDuration(type);
		long startTime = System.currentTimeMillis();
		
		getSharedPreferences("MedievalCity", MODE_PRIVATE).edit()
		.putLong("harvest_" + type + "_start", startTime).apply();
		
		startTimerFromTime(type, startTime);
	}
	
	private void startTimerFromTime(String type, long startTime) {
		long duration = getHarvestDuration(type);
		long remaining = duration - (System.currentTimeMillis() - startTime);
		
		if (remaining <= 0) {
			completeHarvest(type);
			return;
		}
		
		Button btn = type.equals("wood") ? btnForest : btnQuarry;
		btn.setEnabled(false);
		
		String location = type.equals("wood") ? "Forest" : "Quarry";
		
		activeTimer = new CountDownTimer(remaining, 1000) {
			public void onTick(long millisUntilFinished) {
				long sec = millisUntilFinished / 1000;
				tvStatus.setText("⏳ " + location + " - " + (sec/60) + "m " + (sec%60) + "s");
			}
			public void onFinish() {
				completeHarvest(type);
				btn.setEnabled(true);
			}
		}.start();
	}
	
	private boolean isHarvesting(String type) {
		long start = getSharedPreferences("MedievalCity", MODE_PRIVATE)
		.getLong("harvest_" + type + "_start", 0);
		return start > 0 && System.currentTimeMillis() - start < getHarvestDuration(type);
	}
	
	private void completeHarvest(String type) {
		getSharedPreferences("MedievalCity", MODE_PRIVATE).edit()
		.remove("harvest_" + type + "_start").apply();
		
		if (type.equals("wood")) {
			player.setWood(player.getWood() + 10);
			tvStatus.setText("✅ Gathered 10 Wood!");
			} else {
			player.setStone(player.getStone() + 10);
			tvStatus.setText("✅ Gathered 10 Stone!");
			
			if (Math.random() < 0.20) {
				player.addItem(new Item("Iron Ore", 6, 50, 2, 0));
				tvStatus.setText(tvStatus.getText() + "\n🎉 Found Iron Ore!");
			}
		}
		updateResources();
	}
	
	private void updateResources() {
		tvWood.setText("🌲 Wood: " + player.getWood());
		tvStone.setText("⛰️ Stone: " + player.getStone());
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		if (activeTimer != null) activeTimer.cancel();
		if (player != null) player.save(this);
	}
}
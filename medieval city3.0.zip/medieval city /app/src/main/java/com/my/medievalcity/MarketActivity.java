package com.my.medievalcity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MarketActivity extends Activity {
	
	private Player player;
	private TextView tvGold;
	private LinearLayout layoutItems;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_market);
		
		player = MainActivity.getPlayer();
		tvGold = findViewById(R.id.tvPlayerGold);
		layoutItems = findViewById(R.id.layoutItems);
		
		updateGoldDisplay();
		updateInventoryList();
		
		// Buy Buttons
		findViewById(R.id.btnBuyWood).setOnClickListener(v -> buyResource("Wood", 20, 10));
		findViewById(R.id.btnBuyStone).setOnClickListener(v -> buyResource("Stone", 20, 10));
		findViewById(R.id.btnBuyIronSword).setOnClickListener(v -> buyItem("Iron Sword", 10, 300, 18, 0));
		
		findViewById(R.id.btnBack).setOnClickListener(v -> finish());
	}
	
	private void updateGoldDisplay() {
		tvGold.setText("💰 Your Gold: " + player.getGold());
	}
	
	private void buyResource(String type, int cost, int amount) {
		if (player.getGold() >= cost) {
			player.setGold(player.getGold() - cost);
			if (type.equals("Wood")) player.setWood(player.getWood() + amount);
			else player.setStone(player.getStone() + amount);
			updateGoldDisplay();
			Toast.makeText(this, "Bought 10 " + type + "!", Toast.LENGTH_SHORT).show();
			} else {
			Toast.makeText(this, "Not enough gold!", Toast.LENGTH_SHORT).show();
		}
	}
	
	private void buyItem(String name, int id, int cost, int strBonus, int defBonus) {
		if (player.getGold() >= cost) {
			player.setGold(player.getGold() - cost);
			player.addItem(new Item(name, id, 200, strBonus, defBonus)); // sell price 200
			updateGoldDisplay();
			updateInventoryList();
			Toast.makeText(this, "Bought " + name + "!", Toast.LENGTH_SHORT).show();
			} else {
			Toast.makeText(this, "Not enough gold!", Toast.LENGTH_SHORT).show();
		}
	}
	
	private void updateInventoryList() {
		layoutItems.removeAllViews();
		
		for (Item item : player.getInventory()) {
			LinearLayout row = new LinearLayout(this);
			row.setOrientation(LinearLayout.HORIZONTAL);
			row.setPadding(0, 8, 0, 8);
			
			TextView tvItem = new TextView(this);
			tvItem.setText("• " + item.getName() + " (Sell: " + item.getValue() + "g)");
			tvItem.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
			
			Button btnSell = new Button(this);
			btnSell.setText("Sell");
			btnSell.setOnClickListener(v -> {
				sellItem(item);
				updateInventoryList();
				updateGoldDisplay();
			});
			
			row.addView(tvItem);
			row.addView(btnSell);
			layoutItems.addView(row);
		}
		
		if (player.getInventory().isEmpty()) {
			TextView empty = new TextView(this);
			empty.setText("No items to sell.");
			layoutItems.addView(empty);
		}
	}
	
	private void sellItem(Item item) {
		if (player.removeItem(item)) {
			player.setGold(player.getGold() + item.getValue());
			Toast.makeText(this, "Sold " + item.getName() + " for " + item.getValue() + " gold", Toast.LENGTH_SHORT).show();
		}
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		if (player != null) player.save(this);
	}
}